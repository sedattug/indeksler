﻿
<!DOCTYPE html>
<html>
<head>
	
	<title>İndirilebilir Ürünler</title>

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="shortcut icon" type="image/x-icon" href="docs/images/favicon.ico" />
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	
    <link rel="stylesheet" href="leaflet.css"/>
    <script src="leaflet.js" ></script>

<style>
.list-group-item {
    padding: 2px 15px;
	font-weight:bold !important;
}
.list-group-item label{
	font-weight:bold !important;
}

.load{
	width:30px;
	height:30px;
	position:absolute;
	right:2px;
	margin-top:-5px;
	display:none;
}

.download_icon {
	width:40px;
	height:40px;
}

.info_image{
	width:30px;
	height:30px;
	margin-right:10px;
	margin-top:-3px;
}

.list-group-item.active, .list-group-item.active:focus, .list-group-item.active:hover {
    z-index: 2;
    color: #fff;
    background-color: #cdcdcd;
    border-color: #337ab7;
}

.pafta_adi{
	font-size:16px;
}
</style>
	
</head>
<body>
<div class="container">

        <div class="row" style="margin-top:60px;">

            <div class="col-md-3">
                <p class="lead">İndeksler</p>
                <div class="list-group">
                    <a href="#" class="list-group-item">
						<div class="radio">
						  <label><input class="index_check" data-ad="index25" type="radio" name="optradio">indeks 25.000<img class="load" src="img/globe.svg" /></label>
						</div>
					</a>
                    <a href="#" class="list-group-item active">
						<div class="radio">
							  <label><input class="index_check" data-ad="index50" type="radio" name="optradio" checked>indeks 50.000<img class="load" src="img/globe.svg" /></label>
						</div>
					</a>
                    <a href="#" class="list-group-item">
						<div class="radio">
							  <label><input class="index_check" data-ad="index100" type="radio" name="optradio">indeks 100.000<img class="load" src="img/globe.svg" /></label>
						</div>
					</a>
                    <a href="#" class="list-group-item">
						<div class="radio">
							  <label><input class="index_check" data-ad="index250" type="radio" name="optradio">indeks 250.000<img class="load" src="img/globe.svg" /></label>
						</div>
					</a>
                </div>
            </div>

            <div class="col-md-9">

                <div class="thumbnail">
                    <div id="mapid" style="width: 100%; height: 450px;"></div>
                </div>
				
				<div class="row">
					<div class="col-md-12">
						<code class="pafta_adi" style="" ><img class='info_image'  src="img/info.svg" />Görüntüsünü indirmek istediğiniz pafta üzerine tıklayınız...</code>
					</div>
                </div>

                    <hr>
            </div>
			
        </div>

    </div>
    <!-- /.container -->

<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>
	var rectangleArray = []
	var mymap = L.map('mapid').setView([39.050118, 35.211182], 5);

	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
			'<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="http://mapbox.com">Mapbox</a>',
		id: 'mapbox.streets'
	}).addTo(mymap);
	
	
	$(".index_check").click(function(){
		clearRectangles();
		$(".pafta_adi").html("<img class='info_image' src='img/info.svg' />Görüntüsünü indirmek istediğiniz pafta üzerine tıklayınız...");
		var data_ad = $(this).attr("data-ad");
		
		$(".list-group a").each(function(){
			$(this).removeClass("active");
			
		});
		$(".index_check").each(function(){
			$(this).attr("disabled", true);
		});
		setTimeout(function(){
			$(".index_check").each(function(){
				$(this).attr("disabled", false);
			});
		},1500);
		$(this).closest("a").addClass("active");
		$(".list-group").find( "img" ).css("display","none");
		$(this).closest("a").find( "img" ).show();
		
		create_index_layer(data_ad);
	});
	
	
	function create_index_layer(data_ad){
		
		$.getJSON("katmanlar/"+data_ad+"/json/pafta_"+data_ad+".json", function (data) {
			$.each(data, function (key, val) {
				var pafta = val.pafta;
				var north =  val.north;
				var east =  val.east;
				var south =  val.south;
				var west =  val.west;
				var bounds = [[north, east], [south, west]];
				var rect = L.rectangle(bounds, {color: "#ff7800", weight: 1, pafta: pafta}).on('click', function (e){ 
				changecolor();
					var pafta_adi = e.target.options.pafta;
					$(".pafta_adi").fadeIn("slow").html("<img class='download_icon' src='img/download.svg'  style='margin-right:15px;' ></img>Resim URL : images/"+data_ad+"/"+pafta_adi+".tif");
					mymap.fitBounds(bounds);
					rect.setStyle({color: "#4B1BDE"});
					console.log(e);
				});
				
				rectangleArray.push(rect);
				rect.addTo(mymap);
			});
			
		});
		setTimeout(function(){
			$(".load").css("display","none");
		},1500);
		
	}
	create_index_layer("index50");
	
	
	function clearRectangles() {
	  for (var i = 0; i < rectangleArray.length; i++) {
		rectangleArray[i].remove();
	  }
	  rectangleArray = []; 
	}
	
	function changecolor() {
	  for (var i = 0; i < rectangleArray.length; i++) {
		rectangleArray[i].setStyle({color: "#ff7800"});
	  }
	}



</script>



</body>
</html>
